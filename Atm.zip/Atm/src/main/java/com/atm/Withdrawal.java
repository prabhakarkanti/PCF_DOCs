package com.atm;

public class Withdrawal extends Transaction {
	private int amount;

	//initialize constructor
	public Withdrawal(int accountNum, Bank bankData,int amount) {
		
	}

	//check if withdrawal possible
	public boolean isWithdrawalPossible(){
		

	}
	@Override
	public void execute() {
		
	}

}
