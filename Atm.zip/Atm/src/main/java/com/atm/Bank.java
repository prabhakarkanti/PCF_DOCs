package com.atm;

public class Bank {
	private Account[] accounts;

	//initialize constructor
	public Bank(Account accounts[]){
	}

	//return the account for the corresponding account number
	private Account getAccount(int accountNum){
		
	}
	

	//Add your code here
}
