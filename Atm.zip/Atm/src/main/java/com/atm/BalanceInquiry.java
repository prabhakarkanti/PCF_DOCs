package com.atm;

public class BalanceInquiry extends Transaction{
	
	public BalanceInquiry(int accountNum, Bank bankData){
		super(acc_no,bank_data);
	}


	//Print current balance using System.out.println only
	@Override
	public void execute() {
		
	}
	
}
