package com.atm;

public class Account {
	private int accountNum;
	private int pin;
	private int currentBalance;
	
	//initialize constructor
	public Account(int accountNum,int pin,int currentBalance){
        this.accountNum=accountNum;
        this.pin=pin;
        this.currentBalance=currentBalance;
		
	}
	
	int seconds = 0;
	if (p < tickets.length) {
	if (p == 0 && tickets[p] == 1) {
					return 1;
				}

				while (tickets[p] > 0) {

					tickets[0]--;
	if (tickets[0] == 0) {
	if (p != 0) {

							System.arraycopy(tickets, 1, tickets, 0, tickets.length - 1);
	} else {

	break;
	}
	} else {
	int front = tickets[0];
	System.arraycopy(tickets, 1, tickets, 0, tickets.length - 1);
	tickets[tickets.length - 1] = front;
	}
	seconds++;
	if (p != 0) {
	p--;
	} else {
	p = tickets.length - 1;
	}
	}
	}
	return seconds; 
	
	
}

