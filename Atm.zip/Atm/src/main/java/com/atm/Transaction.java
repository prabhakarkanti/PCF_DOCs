package com.atm;

public abstract class Transaction {

	private int accountNum;
	private Bank bankData;
	
	//initilize constructor
	public Transaction(int accountNum,Bank bankData){
		
	}
	
	abstract public void execute();
	

}
