package com.atm;

public class Deposit extends Transaction{
	private int amount;
	public Deposit(int accountNum, Bank bankData,int amount) {
		super(account_no, bank_data);
		this.amount =amount;
	}

	@Override
	public void execute() {
		//Add your code here

	}

}
